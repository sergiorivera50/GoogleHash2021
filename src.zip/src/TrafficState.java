public enum TrafficState {
    RED,
    GREEN,
}
